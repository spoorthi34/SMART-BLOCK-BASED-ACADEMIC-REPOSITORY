# How to Run BlockEdu

## Step-by-Step Instructions

### Prerequisites
- **Node.js** (version 14 or higher) - [Download here](https://nodejs.org/)
- **npm** (comes with Node.js)

### Step 1: Open Terminal/Command Prompt
- **Windows**: Press `Win + R`, type `cmd` or `powershell`, press Enter
- **Mac/Linux**: Open Terminal application

### Step 2: Navigate to Project Directory
```bash
cd "C:\Users\User\Downloads\PBL-SPOORTHI"
```

### Step 3: Install Dependencies
```bash
npm install
```
This will install all required packages (express, pdf-lib, multer, lowdb, etc.)

**Expected output:**
```
added 150 packages in 30s
```

### Step 4: Start the Server
```bash
npm start
```

**Expected output:**
```
🚀 BlockEdu server running on http://localhost:3000
📁 Uploads directory: C:\Users\User\Downloads\PBL-SPOORTHI\uploads
📦 Chunks directory: C:\Users\User\Downloads\PBL-SPOORTHI\chunks
```

### Step 5: Open in Browser
1. Open your web browser (Chrome, Firefox, Edge, etc.)
2. Navigate to: **http://localhost:3000**
3. You should see the BlockEdu landing page!

---

## Alternative: Development Mode (Auto-restart)

If you want the server to automatically restart when you make code changes:

```bash
npm run dev
```

This uses `nodemon` to watch for file changes.

---

## Troubleshooting

### Port Already in Use
If you see an error like "Port 3000 is already in use":

**Option 1:** Change the port in `server.js`:
```javascript
const PORT = process.env.PORT || 3001; // Change to 3001 or any other port
```

**Option 2:** Kill the process using port 3000:
- **Windows:**
  ```bash
  netstat -ano | findstr :3000
  taskkill /PID <PID_NUMBER> /F
  ```
- **Mac/Linux:**
  ```bash
  lsof -ti:3000 | xargs kill
  ```

### Module Not Found Errors
If you see "Cannot find module" errors:
```bash
npm install
```

### Permission Errors
If you get permission errors:
- **Windows:** Run Command Prompt as Administrator
- **Mac/Linux:** Use `sudo` if needed (not recommended for npm install)

---

## Testing the Application

1. **Home Page**: Click "Login to Continue"
2. **Login**: 
   - Select a role (Student/Institution/Recruiter)
   - Enter any email and password
   - Click "Login"
3. **Upload Record** (Student/Institution):
   - Enter a title (e.g., "Bachelor's Degree")
   - Enter Student ID (e.g., "STU001")
   - Click upload area and select a PDF file
   - Click "Upload Record"
   - Watch the blockchain visualization appear!
4. **Verify Record**:
   - Go to "Verify" in navigation
   - Enter a Student ID or Hash
   - Click "Verify"

---

## File Structure After Running

Once you run the application, these directories will be created automatically:
```
PBL-SPOORTHI/
├── uploads/          # Original PDF files
├── chunks/            # Generated chunk PDFs
└── db.json            # Database file
```

---

## Stopping the Server

Press `Ctrl + C` in the terminal to stop the server.

---

## Quick Commands Reference

```bash
# Install dependencies
npm install

# Start server
npm start

# Start in development mode (auto-restart)
npm run dev

# Stop server
Ctrl + C
```

---

## Need Help?

If you encounter any issues:
1. Make sure Node.js is installed: `node --version`
2. Make sure you're in the correct directory
3. Try deleting `node_modules` folder and running `npm install` again
4. Check that port 3000 is not being used by another application

