const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const crypto = require('crypto');
const { PDFDocument } = require('pdf-lib');
const cors = require('cors');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Ensure directories exist
const uploadsDir = path.join(__dirname, 'uploads');
const chunksDir = path.join(__dirname, 'chunks');
fs.ensureDirSync(uploadsDir);
fs.ensureDirSync(chunksDir);

// Database setup
const adapter = new FileSync('db.json');
const db = low(adapter);
db.defaults({ records: [], blocks: [] }).write();

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit - no restrictions
  // No fileFilter - accept ALL file types
});

// Helper function to compute SHA-256 hash
function computeHash(data) {
  return crypto.createHash('sha256').update(data).digest('hex');
}

// Helper function to split PDF into chunks
async function splitPDFIntoChunks(pdfPath, pagesPerChunk = 4) {
  const pdfBytes = await fs.readFile(pdfPath);
  const pdfDoc = await PDFDocument.load(pdfBytes);
  const totalPages = pdfDoc.getPageCount();
  
  const chunks = [];
  const numChunks = Math.ceil(totalPages / pagesPerChunk);
  
  for (let i = 0; i < numChunks; i++) {
    const startPage = i * pagesPerChunk;
    const endPage = Math.min((i + 1) * pagesPerChunk, totalPages);
    
    // Create new PDF for this chunk
    const chunkDoc = await PDFDocument.create();
    const pages = await chunkDoc.copyPages(pdfDoc, Array.from({ length: endPage - startPage }, (_, idx) => startPage + idx));
    
    pages.forEach(page => chunkDoc.addPage(page));
    
    const chunkBytes = await chunkDoc.save();
    const chunkHash = computeHash(chunkBytes);
    const chunkFilename = `chunk-${i + 1}-${Date.now()}.pdf`;
    const chunkPath = path.join(chunksDir, chunkFilename);
    
    await fs.writeFile(chunkPath, chunkBytes);
    
    chunks.push({
      index: i,
      pages: `${startPage + 1}-${endPage}`,
      chunkFilename: chunkFilename,
      chunkHash: chunkHash,
      chunkPath: chunkPath
    });
  }
  
  return { chunks, totalPages };
}

// Helper function to create blockchain
function createBlockchain(chunks, studentId, recordTitle) {
  const blocks = [];
  let prevHash = '0'.repeat(64); // Genesis block hash
  
  chunks.forEach((chunk, index) => {
    const blockData = {
      index: index,
      pages: chunk.pages,
      chunkFilename: chunk.chunkFilename,
      chunkHash: chunk.chunkHash,
      prevHash: prevHash,
      timestamp: new Date().toISOString(),
      studentId: studentId,
      recordTitle: recordTitle
    };
    
    const blockString = JSON.stringify(blockData);
    const blockHash = computeHash(blockString);
    
    const block = {
      ...blockData,
      blockHash: blockHash
    };
    
    blocks.push(block);
    prevHash = blockHash;
  });
  
  return blocks;
}

// API Routes

// Upload file and create blockchain (accepts ALL file types)
app.post('/api/upload', upload.single('pdf'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const { studentId, title } = req.body;
    
    if (!studentId || !title) {
      await fs.remove(req.file.path).catch(() => {});
      return res.status(400).json({ error: 'Student ID and title are required' });
    }
    
    const isPDF = req.file.mimetype === 'application/pdf' || 
                  path.extname(req.file.originalname).toLowerCase() === '.pdf';
    
    let chunks = [];
    let totalPages = 0;
    let blocks = [];
    
    // Only process PDFs for chunking and blockchain
    if (isPDF) {
      try {
        // Split PDF into chunks
        const result = await splitPDFIntoChunks(req.file.path);
        chunks = result.chunks;
        totalPages = result.totalPages;
        
        // Create blockchain
        blocks = createBlockchain(chunks, studentId, title);
      } catch (pdfError) {
        console.error('PDF processing error:', pdfError);
        // Still save the file even if PDF processing fails
        totalPages = 0;
        chunks = [];
        blocks = [];
      }
    } else {
      // Non-PDF file - store it but no chunking
      totalPages = 0;
      chunks = [];
      blocks = [];
    }
    
    // Save record to database (for all file types)
    const record = {
      id: Date.now().toString(),
      studentId: studentId,
      title: title,
      originalFilename: req.file.originalname,
      originalPath: req.file.path,
      fileType: req.file.mimetype,
      fileSize: req.file.size,
      totalPages: totalPages,
      chunks: chunks.length,
      blocks: blocks,
      isPDF: isPDF,
      createdAt: new Date().toISOString()
    };
    
    db.get('records').push(record).write();
    
    // Save blocks to blockchain database (only for PDFs)
    if (blocks.length > 0) {
      blocks.forEach(block => {
        db.get('blocks').push(block).write();
      });
    }
    
    res.json({
      success: true,
      record: {
        id: record.id,
        studentId: record.studentId,
        title: record.title,
        totalPages: record.totalPages,
        chunks: record.chunks,
        blocks: record.blocks,
        isPDF: record.isPDF,
        createdAt: record.createdAt
      }
    });
  } catch (error) {
    console.error('Upload error:', error);
    if (req.file) {
      await fs.remove(req.file.path).catch(() => {});
    }
    res.status(500).json({ error: 'Failed to process file: ' + error.message });
  }
});

// Get all records
app.get('/api/records', (req, res) => {
  try {
    const records = db.get('records').value();
    const simplifiedRecords = records.map(record => ({
      id: record.id,
      studentId: record.studentId,
      title: record.title,
      totalPages: record.totalPages,
      chunks: record.chunks,
      createdAt: record.createdAt
    }));
    res.json({ success: true, records: simplifiedRecords });
  } catch (error) {
    console.error('Get records error:', error);
    res.status(500).json({ error: 'Failed to fetch records' });
  }
});

// Get single record by ID
app.get('/api/records/:id', (req, res) => {
  try {
    const record = db.get('records').find({ id: req.params.id }).value();
    if (!record) {
      return res.status(404).json({ error: 'Record not found' });
    }
    res.json({ success: true, record });
  } catch (error) {
    console.error('Get record error:', error);
    res.status(500).json({ error: 'Failed to fetch record' });
  }
});

// Verify record
app.post('/api/verify', (req, res) => {
  try {
    const { studentId, hash } = req.body;
    
    if (!studentId && !hash) {
      return res.status(400).json({ error: 'Student ID or hash is required' });
    }
    
    let record = null;
    let matchingBlock = null;
    
    if (studentId) {
      record = db.get('records').find({ studentId: studentId }).value();
    }
    
    if (hash) {
      matchingBlock = db.get('blocks').find(block => 
        block.chunkHash === hash || block.blockHash === hash
      ).value();
      
      if (matchingBlock && !record) {
        record = db.get('records').find(r => 
          r.blocks && r.blocks.some(b => b.blockHash === matchingBlock.blockHash)
        ).value();
      }
    }
    
    if (!record) {
      return res.json({
        success: false,
        verified: false,
        message: 'Record not found'
      });
    }
    
    // Verify blockchain integrity
    let isValid = true;
    const blocks = record.blocks;
    for (let i = 1; i < blocks.length; i++) {
      if (blocks[i].prevHash !== blocks[i - 1].blockHash) {
        isValid = false;
        break;
      }
    }
    
    res.json({
      success: true,
      verified: isValid,
      record: {
        id: record.id,
        studentId: record.studentId,
        title: record.title,
        totalPages: record.totalPages,
        chunks: record.chunks,
        blocks: record.blocks,
        createdAt: record.createdAt
      },
      matchingBlock: matchingBlock || blocks[0],
      chainValid: isValid
    });
  } catch (error) {
    console.error('Verify error:', error);
    res.status(500).json({ error: 'Failed to verify record' });
  }
});

// Serve chunk file
app.get('/api/chunks/:filename', (req, res) => {
  const chunkPath = path.join(chunksDir, req.params.filename);
  if (fs.existsSync(chunkPath)) {
    res.sendFile(path.resolve(chunkPath));
  } else {
    res.status(404).json({ error: 'Chunk not found' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 BlockEdu server running on http://localhost:${PORT}`);
  console.log(`📁 Uploads directory: ${uploadsDir}`);
  console.log(`📦 Chunks directory: ${chunksDir}`);
});
