// State Management
let currentUser = null;
let currentRole = null;
let uploadedFile = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeNavigation();
    initializeAuth();
    initializeUpload();
    initializeVerify();
    initializeBackendBlocks();
    checkAuthState();
});

// Navigation
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.getAttribute('data-page');
            if (page === 'logout') {
                logout();
            } else {
                navigateToPage(page);
            }
        });
    });

    // CTA button
    const loginCta = document.getElementById('login-cta');
    if (loginCta) {
        loginCta.addEventListener('click', () => {
            navigateToPage('login');
        });
    }
}

function navigateToPage(page) {
    // Hide all sections
    document.querySelectorAll('.page-section').forEach(section => {
        section.classList.remove('active');
    });

    // Show target section
    const targetSection = document.getElementById(page);
    if (targetSection) {
        targetSection.classList.add('active');
    } else if (page === 'dashboard' && currentRole) {
        // Show appropriate dashboard
        const dashboardId = `${currentRole}-dashboard`;
        const dashboard = document.getElementById(dashboardId);
        if (dashboard) {
            dashboard.classList.add('active');
        }
    } else if (page === 'home') {
        document.getElementById('home').classList.add('active');
    }
}

// Authentication
function initializeAuth() {
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tab = button.getAttribute('data-tab');
            switchTab(tab);
        });
    });

    const loginSubmit = document.getElementById('login-submit');
    const signupSubmit = document.getElementById('signup-submit');

    if (loginSubmit) {
        loginSubmit.addEventListener('click', handleLogin);
    }

    if (signupSubmit) {
        signupSubmit.addEventListener('click', handleSignup);
    }
}

function switchTab(tab) {
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

    document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
    document.getElementById('signup-form').classList.toggle('hidden', tab !== 'signup');
}

function handleLogin() {
    const role = document.getElementById('role-select').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!role || !email || !password) {
        alert('Please fill in all fields');
        return;
    }

    currentUser = { email, role };
    currentRole = role;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    navigateToPage('dashboard');
}

function handleSignup() {
    const role = document.getElementById('signup-role').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    if (!role || !email || !password) {
        alert('Please fill in all fields');
        return;
    }

    currentUser = { email, role };
    currentRole = role;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    navigateToPage('dashboard');
}

function logout() {
    currentUser = null;
    currentRole = null;
    localStorage.removeItem('currentUser');
    navigateToPage('home');
}

function checkAuthState() {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        currentRole = currentUser.role;
    } else {
        navigateToPage('home');
    }
}

// Upload Functionality
function initializeUpload() {
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    const closeModal = document.querySelector('.close-modal');

    // Card buttons that trigger upload
    document.querySelectorAll('.card-button').forEach(button => {
        button.addEventListener('click', (e) => {
            const card = button.closest('.dashboard-card');
            const action = card.getAttribute('data-action');
            
            if (action === 'upload' || action === 'issue') {
                openUploadModal();
            } else if (action === 'view' || action === 'view-issued') {
                alert('View Records feature - Coming soon!');
            } else if (action === 'share') {
                alert('Share Record feature - Coming soon!');
            } else if (action === 'validate') {
                navigateToPage('verify');
            } else if (action === 'verify-candidate') {
                navigateToPage('verify');
            } else if (action === 'request') {
                alert('Request Documents feature - Coming soon!');
            } else if (action === 'received') {
                alert('Received Documents feature - Coming soon!');
            }
        });
    });

    if (uploadArea) {
        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });

        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.backgroundColor = 'rgba(124, 10, 2, 0.1)';
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.style.backgroundColor = 'transparent';
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.backgroundColor = 'transparent';
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        });
    }

    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileSelect(e.target.files[0]);
            }
        });
    }

    if (closeModal) {
        closeModal.addEventListener('click', closeUploadModal);
    }

    // Close modal on outside click
    const modal = document.getElementById('upload-modal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeUploadModal();
            }
        });
    }
}

function openUploadModal() {
    const modal = document.getElementById('upload-modal');
    if (modal) {
        modal.classList.add('active');
        resetUploadModal();
    }
}

function closeUploadModal() {
    const modal = document.getElementById('upload-modal');
    if (modal) {
        modal.classList.remove('active');
        resetUploadModal();
    }
}

function resetUploadModal() {
    document.getElementById('upload-area').classList.remove('hidden');
    document.getElementById('processing-section').classList.add('hidden');
    document.getElementById('chunks-section').classList.add('hidden');
    document.getElementById('backend-flow').classList.add('hidden');
    document.getElementById('file-input').value = '';
    uploadedFile = null;
}

function handleFileSelect(file) {
    if (file.type !== 'application/pdf') {
        alert('Please upload a PDF file');
        return;
    }

    uploadedFile = file;
    document.getElementById('upload-area').classList.add('hidden');
    document.getElementById('processing-section').classList.remove('hidden');
    
    // Simulate processing
    processPDF(file);
}

async function processPDF(file) {
    // Simulate PDF processing with progress
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');
    
    // Simulate page detection
    await animateProgress(0, 30, 500, progressBar, progressText, 'Detecting pages...');
    
    // Simulate chunking
    await animateProgress(30, 60, 800, progressBar, progressText, 'Splitting into chunks...');
    
    // Simulate hashing
    await animateProgress(60, 90, 600, progressBar, progressText, 'Generating hashes...');
    
    // Complete
    await animateProgress(90, 100, 300, progressBar, progressText, 'Processing complete!');
    
    // Simulate page count (random between 8-15 for demo)
    const pageCount = Math.floor(Math.random() * 8) + 8;
    const chunks = createChunks(pageCount);
    
    // Show chunks
    setTimeout(() => {
        document.getElementById('processing-section').classList.add('hidden');
        displayChunks(chunks);
        startBackendFlow(chunks);
    }, 500);
}

function animateProgress(from, to, duration, progressBar, progressText, text) {
    return new Promise((resolve) => {
        if (progressText) progressText.textContent = text;
        let start = null;
        const animate = (timestamp) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            const current = from + (to - from) * progress;
            if (progressBar) progressBar.style.width = current + '%';
            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                resolve();
            }
        };
        requestAnimationFrame(animate);
    });
}

function createChunks(pageCount) {
    const chunksPerChunk = 4;
    const numChunks = Math.ceil(pageCount / chunksPerChunk);
    const chunks = [];

    for (let i = 0; i < numChunks; i++) {
        const startPage = i * chunksPerChunk + 1;
        const endPage = Math.min((i + 1) * chunksPerChunk, pageCount);
        const hash = generateSHA256Hash(`chunk-${i}-${startPage}-${endPage}`);
        
        chunks.push({
            id: i + 1,
            name: `Chunk ${i + 1}`,
            startPage,
            endPage,
            hash
        });
    }

    return chunks;
}

function generateSHA256Hash(input) {
    // Use Web Crypto API if available, otherwise generate deterministic hash
    if (window.crypto && window.crypto.subtle) {
        // For demo, we'll use a simpler deterministic approach
        return deterministicHash(input);
    }
    return deterministicHash(input);
}

function deterministicHash(input) {
    // Simple deterministic hash function for demo
    let hash = 0;
    for (let i = 0; i < input.length; i++) {
        const char = input.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32-bit integer
    }
    
    // Convert to hex-like string
    const hex = Math.abs(hash).toString(16).padStart(8, '0');
    // Repeat to make it look like SHA-256 (64 chars)
    return (hex.repeat(8)).substring(0, 64);
}

function displayChunks(chunks) {
    const chunksSection = document.getElementById('chunks-section');
    const chunksContainer = document.getElementById('chunks-container');
    const chainVisualization = document.getElementById('chain-visualization');
    
    chunksSection.classList.remove('hidden');
    chunksContainer.innerHTML = '';
    chainVisualization.innerHTML = '';
    
    // Display chunk cards
    chunks.forEach((chunk, index) => {
        setTimeout(() => {
            const chunkCard = createChunkCard(chunk);
            chunksContainer.appendChild(chunkCard);
        }, index * 200);
    });
    
    // Display chain visualization
    setTimeout(() => {
        chunks.forEach((chunk, index) => {
            const block = document.createElement('div');
            block.className = 'chain-block';
            block.textContent = `Block ${chunk.id}`;
            chainVisualization.appendChild(block);
            
            if (index < chunks.length - 1) {
                const connector = document.createElement('div');
                connector.className = 'chain-connector';
                chainVisualization.appendChild(connector);
            }
        });
    }, chunks.length * 200);
}

function createChunkCard(chunk) {
    const card = document.createElement('div');
    card.className = 'chunk-card';
    
    card.innerHTML = `
        <div class="chunk-card-header">
            <span class="chunk-name">${chunk.name}</span>
            <span class="chunk-pages">Pages ${chunk.startPage}–${chunk.endPage}</span>
        </div>
        <div class="chunk-hash">${chunk.hash}</div>
        <div class="chunk-actions">
            <button class="chunk-action-btn" onclick="viewChunk('${chunk.id}')">View Chunk</button>
            <button class="chunk-action-btn" onclick="copyHash('${chunk.hash}')">Copy Hash</button>
        </div>
    `;
    
    return card;
}

function viewChunk(chunkId) {
    alert(`Viewing Chunk ${chunkId} - This would display the chunk content in a viewer.`);
}

function copyHash(hash) {
    navigator.clipboard.writeText(hash).then(() => {
        alert('Hash copied to clipboard!');
    }).catch(() => {
        alert('Failed to copy hash');
    });
}

// Backend Flow
function initializeBackendBlocks() {
    const backendBlocks = document.querySelectorAll('.backend-block');
    backendBlocks.forEach(block => {
        block.addEventListener('click', () => {
            showBackendPopover(block);
        });
    });
}

function startBackendFlow(chunks) {
    const backendFlow = document.getElementById('backend-flow');
    backendFlow.classList.remove('hidden');
    
    const blocks = [
        { id: 'api', delay: 0, metadata: { pagesDetected: chunks.reduce((sum, c) => sum + (c.endPage - c.startPage + 1), 0), chunksCreated: chunks.length } },
        { id: 'processor', delay: 1000, metadata: { chunksCreated: chunks.length, processingTime: '2.3s' } },
        { id: 'storage', delay: 2000, metadata: { chunksStored: chunks.length, storageLocation: 'IPFS' } },
        { id: 'blockchain', delay: 3000, metadata: { blocksCreated: chunks.length, transactionHashes: chunks.map(c => c.hash.substring(0, 16) + '...') } }
    ];
    
    blocks.forEach(block => {
        setTimeout(() => {
            activateBackendBlock(block.id, block.metadata);
        }, block.delay);
    });
}

function activateBackendBlock(blockId, metadata) {
    const block = document.querySelector(`[data-block="${blockId}"]`);
    if (!block) return;
    
    block.classList.add('active');
    const content = block.querySelector('.backend-block-content');
    
    let statusText = '';
    switch(blockId) {
        case 'api':
            statusText = `Pages detected: ${metadata.pagesDetected}, Chunks: ${metadata.chunksCreated}`;
            break;
        case 'processor':
            statusText = `Processed ${metadata.chunksCreated} chunks in ${metadata.processingTime}`;
            break;
        case 'storage':
            statusText = `Stored ${metadata.chunksStored} chunks to ${metadata.storageLocation}`;
            break;
        case 'blockchain':
            statusText = `Created ${metadata.blocksCreated} blockchain blocks`;
            break;
    }
    
    if (content) {
        content.textContent = statusText;
    }
    
    // Store metadata for popover
    block.dataset.metadata = JSON.stringify(metadata);
    
    // Remove active class after animation
    setTimeout(() => {
        block.classList.remove('active');
    }, 2000);
}

function showBackendPopover(block) {
    const popover = document.getElementById('backend-popover');
    const title = popover.querySelector('.popover-title');
    const data = popover.querySelector('.popover-data');
    
    const blockName = block.querySelector('.backend-block-header').textContent;
    const metadata = block.dataset.metadata ? JSON.parse(block.dataset.metadata) : {};
    
    title.textContent = blockName;
    
    let dataHTML = '<div>';
    for (const [key, value] of Object.entries(metadata)) {
        if (Array.isArray(value)) {
            dataHTML += `<p><strong>${key}:</strong><br>`;
            value.forEach(item => {
                dataHTML += `<code>${item}</code><br>`;
            });
            dataHTML += `</p>`;
        } else {
            dataHTML += `<p><strong>${key}:</strong> <code>${value}</code></p>`;
        }
    }
    dataHTML += '</div>';
    
    data.innerHTML = dataHTML;
    
    // Position popover near the block
    const rect = block.getBoundingClientRect();
    popover.style.top = (rect.bottom + 10) + 'px';
    popover.style.left = (rect.left + (rect.width / 2) - 200) + 'px';
    popover.classList.remove('hidden');
    
    // Close button
    const closeBtn = popover.querySelector('.popover-close');
    closeBtn.onclick = () => {
        popover.classList.add('hidden');
    };
    
    // Close on outside click
    setTimeout(() => {
        document.addEventListener('click', function closePopover(e) {
            if (!popover.contains(e.target) && !block.contains(e.target)) {
                popover.classList.add('hidden');
                document.removeEventListener('click', closePopover);
            }
        });
    }, 100);
}

// Verify Functionality
function initializeVerify() {
    const verifySubmit = document.getElementById('verify-submit');
    if (verifySubmit) {
        verifySubmit.addEventListener('click', handleVerify);
    }
    
    const verifyInput = document.getElementById('verify-input');
    if (verifyInput) {
        verifyInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleVerify();
            }
        });
    }
}

function handleVerify() {
    const input = document.getElementById('verify-input').value.trim();
    const resultSection = document.getElementById('verify-result');
    const resultStatus = document.getElementById('result-status');
    const resultDetails = document.getElementById('result-details');
    const resultBlocks = document.getElementById('result-blocks');
    
    if (!input) {
        alert('Please enter a Student ID or Hash');
        return;
    }
    
    // Simulate verification
    const isValid = Math.random() > 0.3; // 70% chance of valid
    
    if (isValid) {
        resultStatus.textContent = '✓ Record Verified';
        resultStatus.style.color = '#28a745';
        resultDetails.textContent = `The academic record for ${input} has been verified and is authentic. The record exists on the blockchain and has not been tampered with.`;
        
        // Generate sample block references
        const numBlocks = Math.floor(Math.random() * 3) + 2;
        resultBlocks.innerHTML = '<p style="margin-bottom: 10px; font-weight: 600;">Blockchain References:</p>';
        for (let i = 0; i < numBlocks; i++) {
            const blockRef = document.createElement('span');
            blockRef.className = 'result-block-ref';
            blockRef.textContent = `Block ${i + 1}: ${generateSHA256Hash(input + i).substring(0, 16)}...`;
            resultBlocks.appendChild(blockRef);
        }
    } else {
        resultStatus.textContent = '✗ Record Not Found';
        resultStatus.style.color = '#dc3545';
        resultDetails.textContent = `No record found for ${input}. Please verify the Student ID or Hash and try again.`;
        resultBlocks.innerHTML = '';
    }
    
    resultSection.classList.remove('hidden');
}

