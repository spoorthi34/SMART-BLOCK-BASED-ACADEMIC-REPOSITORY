// API Base URL
const API_BASE = window.location.origin;

// State Management
let currentUser = null;
let currentRole = null;
let allRecords = [];

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    initializeNavigation();
    initializeAuth();
    initializeUpload();
    initializeRecords();
    initializeShare();
    initializeVerify();
    initializeRequest();
    checkAuthState();
});

// Navigation
function initializeNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const page = link.getAttribute('data-page');
            if (page === 'logout') {
                logout();
            } else {
                navigateToPage(page);
            }
        });
    });

    const loginCta = document.getElementById('login-cta');
    if (loginCta) {
        loginCta.addEventListener('click', () => {
            navigateToPage('login');
        });
    }
}

function navigateToPage(page) {
    document.querySelectorAll('.page-section').forEach(section => {
        section.classList.remove('active');
    });

    const targetSection = document.getElementById(page);
    if (targetSection) {
        targetSection.classList.add('active');
    } else if (page === 'dashboard' && currentRole) {
        const dashboardId = `${currentRole}-dashboard`;
        const dashboard = document.getElementById(dashboardId);
        if (dashboard) {
            dashboard.classList.add('active');
            loadRecords();
        }
    } else if (page === 'home') {
        document.getElementById('home').classList.add('active');
    }
}

// Authentication
function initializeAuth() {
    const tabButtons = document.querySelectorAll('.tab-button');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const tab = button.getAttribute('data-tab');
            switchTab(tab);
        });
    });

    const loginSubmit = document.getElementById('login-submit');
    const signupSubmit = document.getElementById('signup-submit');

    if (loginSubmit) {
        loginSubmit.addEventListener('click', handleLogin);
    }

    if (signupSubmit) {
        signupSubmit.addEventListener('click', handleSignup);
    }
}

function switchTab(tab) {
    document.querySelectorAll('.tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');

    document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
    document.getElementById('signup-form').classList.toggle('hidden', tab !== 'signup');
}

function handleLogin() {
    const role = document.getElementById('role-select').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (!role || !email || !password) {
        alert('Please fill in all fields');
        return;
    }

    currentUser = { email, role };
    currentRole = role;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    navigateToPage('dashboard');
}

function handleSignup() {
    const role = document.getElementById('signup-role').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    if (!role || !email || !password) {
        alert('Please fill in all fields');
        return;
    }

    currentUser = { email, role };
    currentRole = role;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    navigateToPage('dashboard');
}

function logout() {
    currentUser = null;
    currentRole = null;
    localStorage.removeItem('currentUser');
    navigateToPage('home');
    updateNavForAuth(false);
}

function checkAuthState() {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        currentRole = currentUser.role;
        updateNavForAuth(true);
    } else {
        updateNavForAuth(false);
    }
}

function updateNavForAuth(isAuthenticated) {
    const loginNav = document.getElementById('login-nav');
    if (loginNav) {
        if (isAuthenticated) {
            loginNav.textContent = 'Logout';
            loginNav.setAttribute('data-page', 'logout');
        } else {
            loginNav.textContent = 'Login';
            loginNav.setAttribute('data-page', 'login');
        }
    }
}

// Upload Functionality
function initializeUpload() {
    // Student upload
    const uploadArea = document.getElementById('upload-area');
    const uploadFile = document.getElementById('upload-file');
    const uploadBtn = document.getElementById('upload-btn');

    if (uploadArea && uploadFile) {
        uploadArea.addEventListener('click', () => uploadFile.click());
        uploadFile.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileSelect(e.target.files[0], 'student');
            }
        });
    }

    if (uploadBtn) {
        uploadBtn.addEventListener('click', () => {
            uploadRecord('student');
        });
    }

    // Institution upload
    const issueUploadArea = document.getElementById('issue-upload-area');
    const issueFile = document.getElementById('issue-file');
    const issueBtn = document.getElementById('issue-btn');

    if (issueUploadArea && issueFile) {
        issueUploadArea.addEventListener('click', () => issueFile.click());
        issueFile.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                handleFileSelect(e.target.files[0], 'institution');
            }
        });
    }

    if (issueBtn) {
        issueBtn.addEventListener('click', () => {
            uploadRecord('institution');
        });
    }

    // Drag and drop
    setupDragAndDrop(uploadArea, uploadFile);
    setupDragAndDrop(issueUploadArea, issueFile);
}

function setupDragAndDrop(area, fileInput) {
    if (!area) return;
    
    area.addEventListener('dragover', (e) => {
        e.preventDefault();
        area.style.backgroundColor = 'rgba(124, 10, 2, 0.1)';
    });

    area.addEventListener('dragleave', () => {
        area.style.backgroundColor = 'rgba(255, 255, 255, 0.5)';
    });

    area.addEventListener('drop', (e) => {
        e.preventDefault();
        area.style.backgroundColor = 'rgba(255, 255, 255, 0.5)';
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            handleFileSelect(files[0], currentRole || 'student');
        }
    });
}

function handleFileSelect(file, type) {
    // Accept ALL file types - no restrictions
    const placeholder = type === 'student' 
        ? document.querySelector('#upload-area .upload-placeholder')
        : document.querySelector('#issue-upload-area .upload-placeholder');
    
    if (placeholder) {
        const isPDF = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
        placeholder.innerHTML = `
            <span class="upload-icon">✓</span>
            <p>${file.name}</p>
            <p class="upload-hint">${(file.size / 1024 / 1024).toFixed(2)} MB ${isPDF ? '(PDF - will be processed)' : '(Non-PDF - stored only)'}</p>
        `;
    }
}

async function uploadRecord(type) {
    const isStudent = type === 'student';
    const titleInput = isStudent ? document.getElementById('upload-title') : document.getElementById('issue-title');
    const studentIdInput = isStudent ? document.getElementById('upload-student-id') : document.getElementById('issue-student-id');
    const fileInput = isStudent ? document.getElementById('upload-file') : document.getElementById('issue-file');
    const progressSection = isStudent ? document.getElementById('upload-progress') : document.getElementById('issue-progress');
    const progressBar = isStudent ? document.getElementById('progress-bar') : document.getElementById('issue-progress-bar');
    const progressText = isStudent ? document.getElementById('progress-text') : document.getElementById('issue-progress-text');
    const visualization = isStudent 
        ? document.getElementById('blockchain-visualization')
        : document.getElementById('institution-blockchain-visualization');
    const blocksContainer = isStudent
        ? document.getElementById('blocks-container')
        : document.getElementById('institution-blocks-container');

    const title = titleInput.value.trim();
    const studentId = studentIdInput.value.trim();
    const file = fileInput.files[0];

    if (!title || !studentId || !file) {
        alert('Please fill in all fields and select a file');
        return;
    }

    const formData = new FormData();
    formData.append('pdf', file);
    formData.append('title', title);
    formData.append('studentId', studentId);

    try {
        progressSection.classList.remove('hidden');
        progressBar.style.width = '0%';
        const isPDF = file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf');
        progressText.textContent = isPDF ? 'Uploading PDF...' : 'Uploading file...';

        // Simulate progress
        await animateProgress(0, 30, 500, progressBar, progressText, isPDF ? 'Uploading PDF...' : 'Uploading file...');
        if (isPDF) {
            await animateProgress(30, 60, 800, progressBar, progressText, 'Processing PDF...');
            await animateProgress(60, 90, 1000, progressBar, progressText, 'Creating blockchain...');
        } else {
            await animateProgress(30, 90, 1000, progressBar, progressText, 'Storing file...');
        }

        const response = await fetch(`${API_BASE}/api/upload`, {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.success) {
            await animateProgress(90, 100, 300, progressBar, progressText, 'Complete!');
            
            setTimeout(() => {
                progressSection.classList.add('hidden');
                if (data.record.blocks && data.record.blocks.length > 0) {
                    displayBlockchain(data.record.blocks, visualization, blocksContainer);
                }
                loadRecords();
                alert('Record uploaded successfully!');
                
                // Reset form
                titleInput.value = '';
                studentIdInput.value = '';
                fileInput.value = '';
                const placeholder = isStudent 
                    ? document.querySelector('#upload-area .upload-placeholder')
                    : document.querySelector('#issue-upload-area .upload-placeholder');
                if (placeholder) {
                    placeholder.innerHTML = `
                        <span class="upload-icon">📄</span>
                        <p>Click to upload any file or drag and drop</p>
                        <p class="upload-hint">PDFs will be processed into blockchain blocks</p>
                    `;
                }
            }, 500);
        } else {
            throw new Error(data.error || 'Upload failed');
        }
    } catch (error) {
        console.error('Upload error:', error);
        alert('Failed to upload record: ' + error.message);
        progressSection.classList.add('hidden');
    }
}

function animateProgress(from, to, duration, progressBar, progressText, text) {
    return new Promise((resolve) => {
        if (progressText) progressText.textContent = text;
        let start = null;
        const animate = (timestamp) => {
            if (!start) start = timestamp;
            const progress = Math.min((timestamp - start) / duration, 1);
            const current = from + (to - from) * progress;
            if (progressBar) progressBar.style.width = current + '%';
            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                resolve();
            }
        };
        requestAnimationFrame(animate);
    });
}

function displayBlockchain(blocks, visualization, container) {
    if (!blocks || blocks.length === 0) return;
    
    visualization.classList.remove('hidden');
    container.innerHTML = '';

    blocks.forEach((block, index) => {
        setTimeout(() => {
            const blockElement = createBlockElement(block, index);
            container.appendChild(blockElement);
            
            if (index < blocks.length - 1) {
                const connector = document.createElement('div');
                connector.className = 'chain-connector';
                container.appendChild(connector);
            }
        }, index * 300);
    });
}

function createBlockElement(block, index) {
    const blockDiv = document.createElement('div');
    blockDiv.className = 'block-3d';
    blockDiv.style.animationDelay = `${index * 0.3}s`;
    
    blockDiv.innerHTML = `
        <span class="block-number">BLOCK ${block.index + 1}</span>
        <span class="block-pages">Pages ${block.pages}</span>
        <span class="block-hash">SHA256: ${block.blockHash.substring(0, 20)}...</span>
        <button class="block-view-btn" onclick="openBlockViewer('${block.blockHash}')">View Chunk</button>
    `;
    
    // Add click handler to the entire block
    blockDiv.addEventListener('click', (e) => {
        if (e.target.tagName !== 'BUTTON') {
            openBlockViewer(block.blockHash);
        }
    });
    
    return blockDiv;
}

function openBlockViewer(blockHash) {
    const block = allRecords
        .flatMap(r => r.blocks || [])
        .find(b => b.blockHash === blockHash);
    
    if (!block) return;
    
    const modal = document.getElementById('block-viewer-modal');
    const content = document.getElementById('block-details-content');
    
    content.innerHTML = `
        <div class="block-detail-item">
            <div class="block-detail-label">Block Number</div>
            <div class="block-detail-value normal">${block.index + 1}</div>
        </div>
        <div class="block-detail-item">
            <div class="block-detail-label">Pages in Chunk</div>
            <div class="block-detail-value normal">${block.pages}</div>
        </div>
        <div class="block-detail-item">
            <div class="block-detail-label">Chunk Hash (SHA-256)</div>
            <div class="block-detail-value">${block.chunkHash}</div>
        </div>
        <div class="block-detail-item">
            <div class="block-detail-label">Block Hash (SHA-256)</div>
            <div class="block-detail-value">${block.blockHash}</div>
        </div>
        <div class="block-detail-item">
            <div class="block-detail-label">Previous Block Hash</div>
            <div class="block-detail-value">${block.prevHash}</div>
        </div>
        <div class="block-detail-item">
            <div class="block-detail-label">Timestamp</div>
            <div class="block-detail-value normal">${new Date(block.timestamp).toLocaleString()}</div>
        </div>
        <div class="block-detail-item">
            <div class="block-detail-label">Chunk Filename</div>
            <div class="block-detail-value normal">${block.chunkFilename || 'N/A'}</div>
        </div>
        ${block.chunkFilename ? `
        <button class="download-chunk-btn" onclick="downloadChunk('${block.chunkFilename}')">Download Chunk PDF</button>
        ` : ''}
    `;
    
    modal.classList.remove('hidden');
}

function closeBlockViewer() {
    const modal = document.getElementById('block-viewer-modal');
    modal.classList.add('hidden');
}

function downloadChunk(filename) {
    window.open(`${API_BASE}/api/chunks/${filename}`, '_blank');
}

// Records Management
async function initializeRecords() {
    await loadRecords();
}

async function loadRecords() {
    try {
        const response = await fetch(`${API_BASE}/api/records`);
        const data = await response.json();
        
        if (data.success) {
            allRecords = [];
            // Load full records
            for (const record of data.records) {
                const fullRecord = await fetch(`${API_BASE}/api/records/${record.id}`).then(r => r.json());
                if (fullRecord.success) {
                    allRecords.push(fullRecord.record);
                }
            }
            
            displayRecords();
            updateShareDropdown();
        }
    } catch (error) {
        console.error('Error loading records:', error);
    }
}

function displayRecords() {
    const recordsList = document.getElementById('records-list');
    const issuedRecordsList = document.getElementById('issued-records-list');
    
    if (recordsList) {
        if (allRecords.length === 0) {
            recordsList.innerHTML = '<p class="loading-text">No records found. Upload your first record!</p>';
        } else {
            recordsList.innerHTML = allRecords.map(record => `
                <div class="record-item">
                    <div class="record-title">${record.title}</div>
                    <div class="record-meta">
                        Student ID: ${record.studentId} | Pages: ${record.totalPages} | Chunks: ${record.chunks} | 
                        Date: ${new Date(record.createdAt).toLocaleDateString()}
                    </div>
                    <div class="record-actions">
                        <button class="record-btn" onclick="viewRecord('${record.id}')">View</button>
                        <button class="record-btn" onclick="viewBlocks('${record.id}')">Blocks</button>
                        <button class="record-btn" onclick="shareRecord('${record.id}')">Share</button>
                    </div>
                </div>
            `).join('');
        }
    }
    
    if (issuedRecordsList) {
        if (allRecords.length === 0) {
            issuedRecordsList.innerHTML = '<p class="loading-text">No records issued yet.</p>';
        } else {
            issuedRecordsList.innerHTML = allRecords.map(record => `
                <div class="record-item">
                    <div class="record-title">${record.title}</div>
                    <div class="record-meta">
                        Student ID: ${record.studentId} | Pages: ${record.totalPages} | Chunks: ${record.chunks} | 
                        Date: ${new Date(record.createdAt).toLocaleDateString()}
                    </div>
                    <div class="record-actions">
                        <button class="record-btn" onclick="viewRecord('${record.id}')">View</button>
                        <button class="record-btn" onclick="viewBlocks('${record.id}')">Blocks</button>
                    </div>
                </div>
            `).join('');
        }
    }
}

function viewRecord(recordId) {
    const record = allRecords.find(r => r.id === recordId);
    if (!record) return;
    
    // Show blockchain view in the records list
    const blockchainView = document.getElementById('record-blockchain-view');
    const blocksContainer = document.getElementById('record-blocks-container');
    
    if (record.blocks && record.blocks.length > 0) {
        blockchainView.classList.remove('hidden');
        blocksContainer.innerHTML = '';
        
        record.blocks.forEach((block, index) => {
            setTimeout(() => {
                const blockElement = createBlockElement(block, index);
                blocksContainer.appendChild(blockElement);
                
                if (index < record.blocks.length - 1) {
                    const connector = document.createElement('div');
                    connector.className = 'chain-connector';
                    blocksContainer.appendChild(connector);
                }
            }, index * 300);
        });
        
        // Scroll to blockchain view
        blockchainView.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
        alert(`Record Details:\n\nTitle: ${record.title}\nStudent ID: ${record.studentId}\nTotal Pages: ${record.totalPages || 0}\nChunks: ${record.chunks || 0}\nCreated: ${new Date(record.createdAt).toLocaleString()}\n\nNote: This is a non-PDF file, so no blockchain blocks were created.`);
    }
}

function viewBlocks(recordId) {
    const record = allRecords.find(r => r.id === recordId);
    if (record && record.blocks) {
        const visualization = currentRole === 'student' 
            ? document.getElementById('blockchain-visualization')
            : document.getElementById('institution-blockchain-visualization');
        const blocksContainer = currentRole === 'student'
            ? document.getElementById('blocks-container')
            : document.getElementById('institution-blocks-container');
        
        displayBlockchain(record.blocks, visualization, blocksContainer);
        visualization.scrollIntoView({ behavior: 'smooth' });
    }
}

// Share Functionality
function initializeShare() {
    const shareBtn = document.getElementById('share-btn');
    if (shareBtn) {
        shareBtn.addEventListener('click', handleShare);
    }
}

function updateShareDropdown() {
    const shareSelect = document.getElementById('share-record-select');
    if (shareSelect) {
        shareSelect.innerHTML = '<option value="">Select a record...</option>' +
            allRecords.map(r => `<option value="${r.id}">${r.title} (${r.studentId})</option>`).join('');
    }
}

function shareRecord(recordId) {
    const shareSelect = document.getElementById('share-record-select');
    if (shareSelect) {
        shareSelect.value = recordId;
    }
}

async function handleShare() {
    const recordId = document.getElementById('share-record-select').value;
    const email = document.getElementById('share-email').value;
    const successMsg = document.getElementById('share-success');
    
    if (!recordId || !email) {
        alert('Please select a record and enter an email');
        return;
    }
    
    // Simulate sharing
    successMsg.classList.remove('hidden');
    setTimeout(() => {
        successMsg.classList.add('hidden');
    }, 3000);
}

// Verify Functionality
function initializeVerify() {
    const verifySubmit = document.getElementById('verify-submit');
    if (verifySubmit) {
        verifySubmit.addEventListener('click', handleVerify);
    }
    
    const verifyInput = document.getElementById('verify-input');
    if (verifyInput) {
        verifyInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                handleVerify();
            }
        });
    }
}

async function handleVerify() {
    const input = document.getElementById('verify-input').value.trim();
    const resultSection = document.getElementById('verify-result');
    const resultStatus = document.getElementById('result-status');
    const resultDetails = document.getElementById('result-details');
    const resultBlocks = document.getElementById('result-blocks');
    
    if (!input) {
        alert('Please enter a Student ID or Hash');
        return;
    }
    
    try {
        const isHash = input.length === 64 || input.length > 40;
        const response = await fetch(`${API_BASE}/api/verify`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                studentId: isHash ? null : input,
                hash: isHash ? input : null
            })
        });
        
        const data = await response.json();
        
        if (data.success && data.verified) {
            resultStatus.textContent = '✓ Record Verified';
            resultStatus.style.color = '#28a745';
            resultStatus.style.background = 'rgba(40, 167, 69, 0.1)';
            
            resultDetails.innerHTML = `
                <p><strong>Record Title:</strong> ${data.record.title}</p>
                <p><strong>Student ID:</strong> ${data.record.studentId}</p>
                <p><strong>Total Pages:</strong> ${data.record.totalPages}</p>
                <p><strong>Chunks:</strong> ${data.record.chunks}</p>
                <p><strong>Created:</strong> ${new Date(data.record.createdAt).toLocaleString()}</p>
                <p><strong>Chain Valid:</strong> ${data.chainValid ? '✓ Yes' : '✗ No'}</p>
            `;
            
            if (data.record.blocks) {
                resultBlocks.innerHTML = '<p style="margin-bottom: 15px; font-weight: 600;">Blockchain Blocks:</p>';
                data.record.blocks.forEach((block, index) => {
                    const blockRef = document.createElement('span');
                    blockRef.className = 'result-block-ref';
                    blockRef.textContent = `Block ${index + 1}: ${block.blockHash.substring(0, 16)}...`;
                    blockRef.title = `Full Hash: ${block.blockHash}`;
                    resultBlocks.appendChild(blockRef);
                });
            }
        } else {
            resultStatus.textContent = '✗ Record Not Found';
            resultStatus.style.color = '#dc3545';
            resultStatus.style.background = 'rgba(220, 53, 69, 0.1)';
            resultDetails.innerHTML = `<p>No record found for "${input}". Please verify the Student ID or Hash and try again.</p>`;
            resultBlocks.innerHTML = '';
        }
        
        resultSection.classList.remove('hidden');
        resultSection.scrollIntoView({ behavior: 'smooth' });
    } catch (error) {
        console.error('Verify error:', error);
        alert('Failed to verify record: ' + error.message);
    }
}

// Request Documents (Recruiter)
function initializeRequest() {
    const requestBtn = document.getElementById('request-btn');
    if (requestBtn) {
        requestBtn.addEventListener('click', () => {
            const studentId = document.getElementById('request-student-id').value;
            const email = document.getElementById('request-email').value;
            const successMsg = document.getElementById('request-success');
            
            if (!studentId || !email) {
                alert('Please fill in all fields');
                return;
            }
            
            successMsg.classList.remove('hidden');
            setTimeout(() => {
                successMsg.classList.add('hidden');
            }, 3000);
        });
    }
}

// Make functions globally available
window.navigateToPage = navigateToPage;
window.viewRecord = viewRecord;
window.viewBlocks = viewBlocks;
window.shareRecord = shareRecord;
window.openBlockViewer = openBlockViewer;
window.closeBlockViewer = closeBlockViewer;
window.downloadChunk = downloadChunk;

