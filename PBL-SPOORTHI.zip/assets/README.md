# Assets Directory

Place the GMU logo file here as `gmu-logo.png`.

The logo should be:
- PNG format (or JPG/SVG)
- Recommended size: 120x50px or similar aspect ratio
- Will be displayed at 50px height in the header

If the logo file is not found, a text placeholder "GMU" will be displayed instead.

